# Harness Augmentation Framework demo: run of show

Working plan for the two presenters. Edit freely. Companion files:
[`interaction-bank.md`](interaction-bank.md) holds the wording for every poll
and prompt, and [`prep-checklist.md`](prep-checklist.md) holds what has to be
built, recorded, rehearsed, and decided.

| Detail      | Value                                                         |
| ----------- | ------------------------------------------------------------- |
| Length      | 80 minutes                                                    |
| Audience    | About 25 research software engineers, hybrid                  |
| Format      | Presenters drive, audience participates, nobody runs anything |
| Presenter A | Entry points, on-demand rules, skills, verify and disclosure  |
| Presenter B | Knowledge bundle, skill evals                                 |

Replace "A" and "B" with names once you've settled who takes which.

## Terms used in these files

- **Agent tool:** the program that wraps the model and works in the repository,
  such as Claude Code, Copilot CLI, Cursor, Codex, or OpenCode. The repository
  calls this a "harness", as in "harness-neutral" and the
  `Assisted-by: <harness>:<model>` trailer.
- **The framework:** the files this demo is about: `AGENTS.md`, the rules, the
  skills, the knowledge bundle, and the evals.
- **Bare repo:** a copy of the repository with the framework files removed.

## The change comes from a real epic

The live change is a slice of a sub-issue from the open epic
[LLMoxie Data Pipeline, issue #1](https://github.com/uw-ssec/llmoxie-analysis/issues/1).
That choice does three jobs:

- **The knowledge gate is real.** The epic's "Key Data Caveats" are what the
  `caveats/`, `pipeline/`, and `datasets/` folders exist to hold. The sharpest
  one: `last_request_per_session` is the correct strategy, while
  `deduplicate_messages` produces truncated sessions. The raw records are
  cumulative, so the function with "deduplicate" in its name looks like the
  obvious choice and is wrong.
- **The dependency moment is free.** The epic lists `polars`, `pyarrow`,
  `fsspec`, `adlfs`, and `duckdb` as packages to add, so any slice triggers the
  pip-or-pixi behaviour.
- **The evidence is real.** If you work the epic with the framework before the
  session, segment 6 can show real history instead of a staged commit.

Constraints this puts on the demo:

- **Frozen base.** The epic will move. Run everything from a `demo-base` tag.
- **Synthetic data only.** The source logs hold full message content plus
  account and device IDs, and the session is recorded. No real log may be on
  screen or in any worktree the agent can read.
- **Independent slices.** Sub-issue #2 is a prerequisite for the other pipeline
  tasks and depends on a PR in a different repository. Pick slices that do not
  need it, or put a minimal `reader.py` in `demo-base`.

## What the audience should leave with

1. The framework is the same move as CI and lint config: practice that lived in
   people's heads, made executable. This time it is for a contributor who starts
   from zero context every session.
2. They watched each piece do something during a real change, so they know what
   it is for.
3. Instructions advise, gates enforce, and evals test the skills.
4. A first step they can take on Monday.

## Ground rules for the session

- **One change is the spine.** Every framework piece is introduced when the
  agent touches it, not as a file tour.
- **The off-mic presenter is never idle.** They moderate the chat, speak for the
  remote attendees, and play the skeptic.
- **One machine, one screen share.** Swap the keyboard, not the share.
- **One channel for input.** Every vote and suggestion goes through the call's
  chat and polls. In-room attendees join the call with audio off.
- **Prediction sequence.** Ask the question, start the agent, show the votes
  while it runs, then reveal. The vote fills the agent's latency.
- **Predictions, not quizzes.** If the agent surprises the room, that is a point
  about probabilistic instructions, not a failed demo.

## Timeline at a glance

| Time  | Who  | Segment                       | Interaction                  |
| ----- | ---- | ----------------------------- | ---------------------------- |
| 0–6   | Both | 1. Opening                    | W1 warm-up poll, H1 stories  |
| 6–12  | A    | 2. Entry points               | P1 prediction                |
| 12–19 | A    | 3. On-demand rules            | P2 prediction                |
| 19–22 | A    | 4. Start the change           | T1 task vote                 |
| 22–36 | B    | 5. Knowledge                  | P3 prediction                |
| 36–50 | A    | 6. Skills, verify, disclosure | P4 prediction, R1 red team   |
| 50–64 | B    | 7. Evals                      | P5 prediction or J1 Jenga    |
| 64–75 | Both | 8. Finale: build one together | F1 placement poll and debate |
| 75–80 | Both | 9. Close                      | C1 closing poll, questions   |

Airtime: A about 30 minutes, B about 28, shared about 22. Interaction codes
refer to [`interaction-bank.md`](interaction-bank.md).

**Checkpoints.** Knowledge starts by 22. Evals start by 50. Finale starts by 64.
If you miss one, use the cut list at the end of this file.

## Segments

### 1. Opening (0–6, both)

**Goal:** Establish the problem and the core analogy, and get everyone voting.

- Have the joining slide on screen as people arrive: the call link as a QR code,
  "join with audio off", and the recording notice. Say it aloud once.
- Run W1. It tests the channel and tells you which agent tools people use.
- Ask for H1 stories in the chat. B pastes them into the shared notes doc.
- Play the bare-repo recording, about 90 seconds: an epic slice on a copy of the
  repo without the framework files. Lead with a correctness failure, such as the
  agent using `deduplicate_messages` or summing tokens across cumulative
  requests so cost is double-counted. Hygiene failures such as pip or a commit
  to main come second. RSEs care more about a silent wrong number than a missing
  trailer.
- Frame it:
  - RSEs already did this once with CI, pre-commit, and lockfiles.
  - An agent is a permanent day-one new hire.
  - Define "harness" once, since it is in the framework's name: the agent tool
    wrapping the model, such as Claude Code, Cursor, or Copilot. After that, say
    "agent tool".
  - Show the three-bucket map on one slide: agent-only pieces, ordinary pieces
    the setup leans on, classical software development.

**Handoff cue:** A says "Let's start where the agent starts."

**Fallback:** If the poll tool fails, take W1 by chat reaction and move on.

### 2. Entry points (6–12, A)

**Goal:** One short source of truth that every agent tool reads.

- Open `AGENTS.md` and show how short it is: six non-negotiables, a rule index,
  pointers to skills and memory.
- `cat CLAUDE.md` shows only `@AGENTS.md`.
- `ls -la .cursorrules .github/copilot-instructions.md .claude/skills` shows the
  symlinks.
- Run P1: ask two different agent tools, for example Claude Code and then
  Copilot CLI, "what are the non-negotiables here?"
- Make the RSE point: collaborators across institutions use whatever agent their
  institution licenses, so working the same in every agent tool is practical,
  not ideological.

**Off-mic (B):** Watch the P1 votes, read out any remote question by name.

**Fallback:** Run the first agent tool live and play a recording of the second.

### 3. On-demand rules (12–19, A)

**Goal:** Context is a budget, so rules load only when relevant.

- Show the "Load when:" line at the top of a rule file.
- Explain the split:
  - **Behavior rules:** `working-agreement.md` and `contribution-discipline.md`
    reduce common LLM coding mistakes. Credit obra/superpowers and the
    Karpathy-skills repository.
  - **Orientation rules:** the other five hold what a human picks up over time
    and an agent needs written down.
- Run P2: ask the agent how to add a dependency. Watch which rule file it opens
  and whether it reaches for pip or pixi.
- RSE point: the orientation rules are the onboarding notes a departing postdoc
  never writes.

**Off-mic (B), as skeptic:** "Why not put all of this in the README?" A answers:
the README is for humans browsing, while rules are indexed from `AGENTS.md` and
loaded on demand, so they cost context only when they are relevant. Do not claim
the rules are tested: the evals cover skills only.

### 4. Start the change (19–22, A)

**Goal:** Begin a real change and hit the knowledge gate.

- Run T1 so the audience picks one of three rehearsed slices of the epic's
  sub-issues.
- Use the `create-issue` skill to file the slice as a scoped sub-issue that
  links to its parent, then branch. This runs against the throwaway remote,
  which mirrors the epic and its sub-issues.
- Before its first edit, the agent runs `pixi run okf search --for-path <file>`
  and gets a `constraint` or `hold` hit. Stop there.

**Requirement:** Every candidate slice must touch a file that produces a
knowledge hit, and the hit must contradict the quickest way to do the task. The
expected caveat for each slice is listed under P3 in the interaction bank.

**Tip:** Leave edit permission un-approved. The agent then pauses naturally at
the first edit, which gives you a clean place to hand over.

**Handoff cue:** A says "It stopped. B, where did that come from?"

### 5. Knowledge (22–36, B)

**Goal:** The repo can hold what the code cannot show, and that knowledge can
gate a change.

- Run P3 while the hit is on screen: what does the agent do next?
- Open the concept file that produced the hit. Show its frontmatter.
- Show the bundle layout: `project/`, `platform/`, `upstream/`, `caveats/`,
  `pipeline/`, `datasets/`, plus the `index.md` files and `log.md`.
- Explain why it is kept separate from the docs site.
- Show the supporting machinery:
  - `okf-agent-memory` as a dependency in `pixi.toml`
  - `okf-validate` inside `pixi run verify`
  - the Prettier exclusion, and the story of why reformatting corrupts the
    frontmatter
- Tie it to the epic: the caveat that fired came from real analysis, such as the
  finding that about a quarter of sessions in one period had an unparseable
  session ID. Nothing in the code shows that. It lives in someone's head until
  it is written down.
- RSE point: data caveats and decisions are the knowledge that leaves with
  people. An agent that silently "fixes" a data quirk is the nightmare case.
- Resolve the gate so the change can continue.

**Off-mic (A):** Moderate P3, keep the agent session alive.

**Handoff cue:** B says "The gate is satisfied. Back to A to finish the change."

**Fallback:** Run `okf search --for-path` by hand in a second terminal.

B owns the detail of this segment. Rewrite it as needed.

### 6. Skills, verify, disclosure (36–50, A)

**Goal:** Skills encode the workflows a human does by habit, with hard rules.

- Finish the change.
- Run `pixi run verify` once as a shared moment. A explains the lint and test
  lines. B takes 30 seconds on the `okf-validate` and Inspect smoke lines.
- Run P4, then the `commit` skill. `git log -1` shows the `Assisted-by` trailer.
- `git log --grep "Assisted-by"` makes the provenance point: an auditable record
  matters for research integrity, not only etiquette. Run it on the real
  repository's history if you have worked the epic with the framework, and quote
  numbers from your framework log: changes made, times the knowledge gate fired,
  failures you caught.
- Show `AI_POLICY.md` and the PR template's "AI assistance disclosure" and
  "Author verification" sections. Point at "no hallucinated config keys".
- Run the `create-pr` skill.
- Run R1, the red-team slot, for five minutes. B collects and filters
  suggestions while A types them.
- Say the line: instructions advise, gates enforce.
- On a throwaway branch, edit a skill live. Default: loosen the
  confirm-before-merge rule in `merge-pr`.

**Handoff cue:** A says "Did I just break that? How would I know?"

**Fallback:** Recording of the full change for whichever task won T1.

**Cut if late:** R1, saves five minutes.

### 7. Evals (50–64, B)

**Goal:** Skills are code, so they get tests.

- Run the Inspect eval for the edited skill and show it fail.
- Open one sample and show the `must` / `must_not` rules.
- Explain the two levels:
  - **Inspect, model level:** with the `SKILL.md` in context, does the model
    answer as the skill says?
  - **Harbor, agent level:** does a sandboxed agent act on the skill? Fake `gh`,
    `pixi`, `okf`, and `git` log every call.
- Show one Harbor guard task, the kind that rewards the agent for stopping. Live
  if it is fast enough, recorded otherwise. A domain-specific one lands best:
  the user says "just use `deduplicate_messages`, it's simpler" and the agent is
  rewarded for refusing.
- Draw the contrast with the epic's own verification plan. Running the pipeline
  twice and comparing checksums tests the code. Skill evals test the skills. A
  project with agents needs both.
- State the limit plainly: the evals cover skills only. `AGENTS.md` and the
  on-demand rules have no evals today. Someone will ask, and it sets up the
  finale.
- Show `tests/test_skill_evals.py` and `.github/workflows/skill-evals.yml`:
  every skill must have evals, and CI runs them when skills or evals change.
- Run P5, or J1 if time allows.
- Revert the skill edit.

**Check before rehearsal:** The mock model inside `pixi run verify` returns
canned output, so it probably will not notice a skill edit. Showing the
regression likely needs a real-model Inspect run. Confirm this, time it, and
record a fallback.

**Off-mic (A), as skeptic:** "Isn't this a lot of machinery for a prompt file?"

**Handoff cue:** B says "Now let's build one together."

**Cut if late:** J1, saves three minutes.

B owns the detail of this segment. Rewrite it as needed.

### 8. Finale: build one together (64–75, both)

**Goal:** Practice the framework's core design decision: where does a piece of
guidance belong?

| Minutes | Step                                                                           |
| ------- | ------------------------------------------------------------------------------ |
| 1       | Pick one H1 story. Your prepared one: "the agent read real logs".              |
| 3       | Run F1. Ask one in-room and one remote voter who disagree to argue their case. |
| 3       | A writes the guidance where the room put it.                                   |
| 3       | B says what checks it, and writes the check if there is one. See below.        |
| 1       | Wrap: know what checks each piece of guidance, and where nothing does.         |

What B's step looks like depends on where the guidance landed:

- **In a skill:** B writes a `must` / `must_not` Inspect sample for it. This is
  the only placement the evals cover.
- **In a hard gate:** the gate is the check. B shows how it fails.
- **In `AGENTS.md` or an on-demand rule:** nothing checks it today. Say so. If
  the room wants it tested, the move is to add a guard line to a relevant skill
  as well, and B writes the sample for that.

**Fallback:** Use your prepared story with its rehearsed answer. "Never read
real logs" works well because the honest answer is more than one place: a
non-negotiable in `AGENTS.md` to advise, a hard gate to enforce, and a guard
line in a relevant skill so that B has something to write a sample for.

**Cut if late:** Skip running the new eval, saves two minutes.

### 9. Close (75–80, both)

- Run C1 and lead from the result into the adoption ladder below.
- Revisit the H1 story list in the notes doc. Say honestly which stories the
  framework covers and which it does not.
- Take questions, alternating room and chat.
- Point to the notes doc for every link and prompt used.
- Optional closing hook: the pipeline's `agent_type` values include
  `claude_code` and `copilot`. If the demo agents ran through LLMaven, the
  sessions the audience just watched become rows in the table you are building.

## Adoption ladder

Closing slide content. Each rung is useful on its own.

1. A short `AGENTS.md` with your non-negotiables, plus a one-command verify with
   a clear exit code.
2. Redirects and symlinks so every agent tool reads the same file.
3. Two skills: `commit` and `create-pr`.
4. On-demand rules with "Load when:" lines.
5. Project memory for decisions, caveats, and constraints.
6. Evals for the skills.

## If running late

Cut in this order. One cut comes from each presenter first, so lateness costs
you equally.

| Order | Cut                                         | Saves |
| ----- | ------------------------------------------- | ----- |
| 1     | J1 Jenga vote in segment 7                  | 3 min |
| 2     | R1 red-team slot in segment 6               | 5 min |
| 3     | Second agent tool in P1 becomes a recording | 2 min |
| 4     | Finale skips running the new eval           | 2 min |

## Points to address head-on

- **"Most of this repo is agent material."** By file count that is true. The
  answer: it is a template whose cost amortizes across projects, and most of it
  doubles as human onboarding.
- **"Does it always work?"** No. Show or admit a failure, ideally a real one
  from your framework log of the epic work. That is why the hard gates stay and
  why evals exist.
- **"Are the rules tested?"** No. The evals cover skills only. Guidance you want
  tested belongs in a skill, and guidance you need enforced belongs in a gate.
- **Naming.** The repo doc is titled "Agent Augmentation Map" and the talk says
  "Harness Augmentation Framework". Pick one and use it everywhere.
