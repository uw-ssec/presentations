# Prep checklist

What has to be decided, built, recorded, and rehearsed before the session in
[`run-of-show.md`](run-of-show.md). Owners are A, B, or Both. Reassign freely.

## Open decisions

Settle these first. Several later items depend on them.

- [ ] **Names and date.** Replace A and B throughout. (Both)
- [ ] **One name for the framework.** "Harness Augmentation Framework" or the
      repo doc's "Agent Augmentation Map". (Both)
- [ ] **Meeting platform.** It needs polls, chat reactions, and recording.
      (Both)
- [ ] **Session date against epic progress.** How far along will the epic be?
      This decides which slices are still open and whether `reader.py` exists.
      (Both)
- [ ] **The three slices for T1.** Start from the candidates in
      [`interaction-bank.md`](interaction-bank.md) and check each against the
      criteria there. Read sub-issue #10 closely before keeping it. (A picks, B
      confirms each one produces a knowledge hit)
- [ ] **Where the pipeline modules live.** The epic says `data/sources.py` and
      `python -m data.pipeline`, but the package is `src/llmoxie_analysis/`.
      Decide, then record it in `repository-map.md` or the knowledge bundle.
      Otherwise the agent guesses, differently each run. (Both)
- [ ] **Whether `reader.py` goes into `demo-base`.** It unlocks the stretch
      slice and the strongest opening recording. (A)
- [ ] **Whether the demo agents run through LLMaven.** Needed for the optional
      closing hook. (Both)
- [ ] **Which two agent tools appear in P1.** Use W1-style guesses about the
      audience: probably Copilot plus one other. (A)
- [ ] **Which skill edit drives the handoff to evals.** Default: loosen
      confirm-before-merge in `merge-pr`. (A and B together, since B's eval must
      catch it)
- [ ] **Mock or real model for the eval regression.** The mock model in
      `pixi run verify` probably won't notice a skill edit. Confirm, then decide
      between a live real-model run and a recording. (B)
- [ ] **What the evals cover.** The repo map describes skill evals only. Confirm
      that, and check whether any Harbor task exercises `AGENTS.md` or a rule
      indirectly. The finale and the "are the rules tested?" answer depend on
      it. (B)
- [ ] **Where the demo runs.** A local machine or a codespace. Local avoids one
      network dependency. (A)
- [ ] **Recording consent.** Decide whether the session is recorded. If it is,
      say so on the opening slide and aloud before you start. (Both)

## Start now, while working the epic

- [ ] Keep a framework log as you work the epic with the framework: each change
      made, each time the knowledge gate fired, each failure you caught and how.
      It feeds segment 6, the "does it always work?" answer, and your prepared
      finale story. (Both)

## Build

- [ ] `demo-base` tag on a frozen commit. Every run starts from a worktree of
      it. (A)
- [ ] Synthetic fixtures only: a small `.jsonl` of invented cumulative request
      records. No real log in any worktree the agent can read. (A)
- [ ] Epic #1 and its sub-issues mirrored to the throwaway remote, so
      `create-issue` can link a slice to its parent. (A)
- [ ] Each slice written as a scoped issue body. (A)
- [ ] A domain-specific Harbor guard task: the user asks for
      `deduplicate_messages` and the agent is rewarded for refusing. (B)
- [ ] Bare copy of the repo with the framework files removed, for the opening
      recording and the J1 variants. (A)
- [ ] Throwaway GitHub repo as the remote, so `create-issue`, `create-pr`, and
      the red-team slot don't touch the real one. (A)
- [ ] Reset script: fresh worktree, clean branch, closed issues and PRs on the
      throwaway remote. (A)
- [ ] Pre-warmed pixi environments in the demo location. (A)
- [ ] Agent permission settings: pre-approve everything except the prompts you
      want the audience to see, such as the first edit and the merge. (A)
- [ ] Pinned model version for every agent shown, noted in the notes doc. (A)
- [ ] A knowledge entry for each slice's file that produces a `constraint` or
      `hold` hit and contradicts the quick way to do the task. The expected
      caveats are listed under P3 in the interaction bank. (B)
- [ ] The prepared finale story, "the agent read real logs", with its
      non-negotiable, its hard gate, and a guard line in a relevant skill with
      its `must` / `must_not` sample drafted. Evals cover skills only, so the
      sample has to target the skill. Swap in a better one from the framework
      log if you get one. (Both)
- [ ] Slides: the three-bucket map, the CI analogy, the adoption ladder, and a
      slide per poll showing the question. (Both)
- [ ] Shared notes doc with links, every prompt from the interaction bank, and
      an empty horror-story table with a "covered by" column. (B)
- [ ] All polls created in the platform, in timeline order. (B)

## Record

Every live step needs a recorded fallback. Keep each clip short and named by
segment.

- [ ] Bare-repo run of an epic slice, about 90 seconds. Keep whatever actually
      goes wrong. Aim first for a correctness failure: `deduplicate_messages`,
      or tokens summed across cumulative requests. Then hygiene: pip instead of
      pixi, a commit straight to main, a missing trailer. Synthetic data only.
      (A)
- [ ] The second agent tool answering P1. (A)
- [ ] The full change, once for each of the three T1 candidates. (A)
- [ ] The knowledge hit and the agent's response to it. (B)
- [ ] Real-model Inspect run failing on the edited skill. (B)
- [ ] One Harbor guard task, start to finish. (B)
- [ ] Three J1 variants: no rules, no skills, no knowledge bundle. (A and B)

## Rehearse

- [ ] Run each prediction prompt about five times. Write the spread into the
      "Observed in rehearsal" lines. Drop or reword any prediction that is
      unstable. (whoever owns the segment)
- [ ] Time each segment alone. (each)
- [ ] Joint run-through with every handoff cue spoken and every keyboard swap
      done. (Both)
- [ ] Practice the off-mic role: reading chat aloud, alternating room and
      remote, asking the skeptic questions. (Both)
- [ ] Practice the cut list once, so dropping R1 or J1 mid-session is smooth.
      (Both)
- [ ] Technical rehearsal in the actual room, with one person dialled in
      remotely to check font size, audio, and poll visibility. (Both)

## Hybrid and room setup

- [ ] Terminal at 18–20 pt or larger, high-contrast theme. (A)
- [ ] Agent and file view side by side, no window switching. (A)
- [ ] Room microphone that picks up audience questions, or a habit of repeating
      every in-room question before answering. (Both)
- [ ] Opening slide with the call link as a QR code, the instruction to join
      with audio off, and the recording notice. Have it on screen while people
      arrive. (Both)
- [ ] Hotspot ready as a network backup. (A)
- [ ] Fallback recordings in one folder, tested on the demo machine. (Both)

## Day of

- [ ] Run the reset script. (A)
- [ ] Open the notes doc, the poll list, and the fallback folder. (B)
- [ ] Check the screen share from a second device. (B)
- [ ] Start the recording. (Both)
- [ ] Put the checkpoint times where you can both see them: 22, 50, 64. (Both)

## After

- [ ] Fill in the "covered by" column of the horror-story table and share the
      notes doc. (B)
- [ ] Note which predictions surprised the room. They are the best material for
      the next version. (Both)
